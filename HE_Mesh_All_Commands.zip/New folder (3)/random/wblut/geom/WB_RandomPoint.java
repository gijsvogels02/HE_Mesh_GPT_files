package wblut.geom;

public interface WB_RandomPoint extends WB_PointGenerator{

}
