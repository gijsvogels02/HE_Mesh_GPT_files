package wblut.geom;

public interface WB_RandomVector extends WB_VectorGenerator{

}
